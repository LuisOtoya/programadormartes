This template / effect / code has been created by Mandy Michael.
You can customize and check it out on its original site on the following link:
https://codepen.io/mandymichael/pen/wpYQKx

Thank you